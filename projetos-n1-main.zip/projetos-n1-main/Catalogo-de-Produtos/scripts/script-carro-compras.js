function incrementar() {
        var contador = document.getElementById("contador");
        contador.innerHTML = parseInt(contador.innerHTML) + 1;
      }