function showSubIcons() {
			var subIcons = document.querySelector('.sub-icons');
			subIcons.style.display = subIcons.style.display === 'none' ? 'block' : 'none';
		}